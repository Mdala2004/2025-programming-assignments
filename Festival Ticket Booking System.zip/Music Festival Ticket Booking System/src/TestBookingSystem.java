import java.util.Scanner;

public class TestBookingSystem {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //this invokes the events.append for the two seeded events
        bookingSystem system = new bookingSystem();

        //menu seen by the user
        int choice;
        char select;

            System.out.println("Hello, and welcome to the ticket booking system!");
            System.out.println("First off, are you a: \n User(Press u if you are) or \n An event creator(Press c if you wish to add an event to our system): ");
            select = input.next().charAt(0);
        
        if(select == 'c' || select == 'C'){
            do{
                System.out.println(" EVENTS CREATOR ");
                System.out.println("Select: ");
                System.out.println("1 to create an event");
                System.out.println("0 to exit the system entirely");

                //handle bad input safely
                try{
                    choice = Integer.parseInt(input.nextLine());
                } catch(NumberFormatException e){
                    choice = -1;
                }

                switch(choice){
                    case 1:
                    system.createEvent(input);
                    break;

                    case 0:
                    System.out.println("Goodbye!");
                    break;

                    default:
                    System.out.println("Invalid choice. Please enter either 1 or 0.");
                }
            } while(choice != 0);

            input.close();
        } 
        else if(select == 'u' || select == 'U'){
            do {
            System.out.println("\n BOOKING TICKET SYSTEM ");
            System.out.println("1. Book a Ticket");
            System.out.println("2. Cancel a Booking");
            System.out.println("3. Check a Booking");
            System.out.println("4. Display All Attendees");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            //handle bad input safely
            try {
                choice = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                choice = -1; //invalid choice
            }

            switch(choice) {
                case 1:
                    system.bookTicket(input);
                    break;
                case 2:
                    system.cancelBooking(input);
                    break;
                case 3:
                    system.checkBooking(input);
                    break;
                case 4:
                    system.displayAttendees();
                    break;
                case 5:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 5.");
            }
        } while (choice != 5);

        input.close();
    }      
}
}