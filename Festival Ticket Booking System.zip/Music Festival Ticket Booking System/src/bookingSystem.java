import java.util.Random;
import java.util.Scanner;

/*Hello sir. I decided to modify your Linked list class in order to be able to implement my own changes here.
 there are a few methods that are critical to the functioning of the system that i added to the linked list class provided.
 Hopefully this doesn't prove to be an inconvenience as you mark the project.
 */
public class bookingSystem {
    private MyLinkedList<Event> events = new MyLinkedList<>();
    private MyLinkedList<Attendee> attendees = new MyLinkedList<>();

    //create events to store in events list(eventID is written as E, then 00 something to signify the place the event in the list)
    public bookingSystem() {
        events.append(new Event("E001", "2025-09-01", "Cape Town", "Main Stage", 3));
        events.append(new Event("E002", "2025-09-02", "Johannesburg", "Rock Arena", 2));
    }

    public void bookTicket(Scanner input) {
        System.out.println("Available Events:");
        events.traverse();

        System.out.print("Enter Event ID to book event: ");
        String eventID = input.nextLine();

        Event selected = findEvent(eventID);

        if (selected == null || !selected.hasAvailableSeats()) {
            System.out.println("Event not found or fully booked.");
            return;
        }

        System.out.print("Enter Seat Number: ");
        String seat = input.nextLine();
        System.out.print("Enter ID Number: ");
        String id = input.nextLine();
        System.out.print("Enter Name: ");
        String name = input.nextLine();
        System.out.print("Enter Surname: ");
        String surname = input.nextLine();
        System.out.print("Enter Contact Number: ");
        String contact = input.nextLine();
        System.out.print("Enter Email: ");
        String email = input.nextLine();

        Attendee newAttendee = new Attendee(id, name, surname, contact, email, eventID, seat);

        //Spin the wheel 
        String[] prizes = {"VIP Pass Upgrade", "Free Festival T-Shirt", "Backstage Access", "Food Voucher"};
        Random rand = new Random();
        newAttendee.setPrize(prizes[rand.nextInt(prizes.length)]);

        attendees.append(newAttendee);
        selected.bookSeat();

        System.out.println("Booking successful! Prize: " + newAttendee.getPrize());
    }

    public void cancelBooking(Scanner input) {
        System.out.print("Cancel by (1) ID Number or (2) Event ID + Seat?");
        int choice = Integer.parseInt(input.nextLine());

        Attendee found = null;

        if (choice == 1) {
            System.out.print("Enter ID Number: ");
            String id = input.nextLine();
            found = findAttendeeByID(id);
        } else {
            System.out.print("Enter Event ID: ");
            String eventid = input.nextLine();
            System.out.print("Enter Seat Number: ");
            String seat = input.nextLine();
            found = findAttendeeByEventSeat(eventid, seat);
        }

        if (found != null) {
            attendees.delete(found);
            Event e = findEvent(found.getEventID());
            if (e != null) 
            e.cancelSeat();
            System.out.println("Booking cancelled for " + found);
        } else {
            System.out.println("Booking not found.");
        }
    }

    public void checkBooking(Scanner input) {
        System.out.print("Enter ID Number: ");
        String id = input.nextLine();

        Attendee a = findAttendeeByID(id);
        if (a != null) {
            System.out.println("Booking found: " + a);
        } else {
            System.out.println("No booking found for ID " + id);
        }
    }

    public void displayAttendees() {
        System.out.println("All Attendees:");
        attendees.traverse();
    }

    //Helper Methods to help with finding different items inside the nodes
    private Event findEvent(String eventID) {
    MyLinkedList.Node<Event> current = events.getHead();
    while (current != null) {
        if (current.element.matches(eventID)) {
            return current.element;
        }
        current = current.next;
    }
    return null;
    }

    private Attendee findAttendeeByID(String id) {
        MyLinkedList.Node<Attendee> current = attendees.getHead();
        while (current != null) {
            if (current.element.matchesID(id)) {
                return current.element;
            }
            current = current.next;
        }
        return null;
    }

    private Attendee findAttendeeByEventSeat(String eventID, String seat) {
    MyLinkedList.Node<Attendee> current = attendees.getHead();
    while (current != null) {
        if (current.element.matchesEventSeat(eventID, seat)) {
            return current.element;
        }
        current = current.next;
    }
    return null;
    }

    public void createEvent(Scanner input) {
        System.out.println("Enter the following details to create a new event:");

        System.out.print("Event ID: ");
        String eventID = input.nextLine();

        System.out.print("Date (YYYY-MM-DD): ");
        String date = input.nextLine();

        System.out.print("Location: ");
        String location = input.nextLine();

        System.out.print("Stage Name: ");
        String stageName = input.nextLine();

        System.out.print("Total Seats: ");
        int totalSeats = Integer.parseInt(input.nextLine());

        Event newEvent = new Event(eventID, date, location, stageName, totalSeats);
        events.append(newEvent);

        System.out.println("Event created successfully: " + newEvent);
    }
}

//These are seperate classes to maintain order and be able to use the linked lists with all of the required features
 class Event {
    private String eventID;
    private String date;
    private String location;
    private String stageName;
    private int totalSeats;
    private int bookedSeats;

    public Event(String eventID, String date, String location, String stageName, int totalSeats) {
        this.eventID = eventID;
        this.date = date;
        this.location = location;
        this.stageName = stageName;
        this.totalSeats = totalSeats;
        this.bookedSeats = 0;
    }

    public String getEventID(){
        return eventID;
    }
    public String getDate(){
        return date;
    }
    public String getLocation(){
        return location;
    }
    public String getStageName(){
        return stageName;
    }
    public int getTotalSeats(){
        return totalSeats;
    }
    public int getBookedSeats(){
        return bookedSeats;
    }

    public boolean hasAvailableSeats() {
        return bookedSeats < totalSeats;
    }

    public void bookSeat() {
        if (hasAvailableSeats()) 
            bookedSeats++;
    }

    public void cancelSeat() {
        if (bookedSeats > 0) 
            bookedSeats--;
    }

    public boolean matches(String id) {
        return this.eventID.equalsIgnoreCase(id);
    }

    @Override
    public String toString() {
        return "Event: [ Event ID: " + eventID + " - Date:  " + date + " - Location: " + location +
               " - Stage Name: " + stageName + " - Seats: " + bookedSeats + "/" + totalSeats + "]";
    }
}

class Attendee {
    private String idNumber;
    private String name;
    private String surname;
    private String contactNumber;
    private String email;
    private String eventID;
    private String seatNumber;
    private String prize;

    public Attendee(String idNumber, String name, String surname, String contactNumber, String email, String eventID, String seatNumber) {
        this.idNumber = idNumber;
        this.name = name;
        this.surname = surname;
        this.contactNumber = contactNumber;
        this.email = email;
        this.eventID = eventID;
        this.seatNumber = seatNumber;
    }

    public String getIdNumber(){ 
        return idNumber; 
    }

    public String getName(){ 
        return name;
    }

    public String getSurname(){
        return surname; 
    }

    public String getContactNumber(){
        return contactNumber; 
    }

    public String getEmail(){
        return email;
     }

    public String getEventID(){
        return eventID;
     }

    public String getSeatNumber(){
        return seatNumber; 
    }

    public String getPrize(){
        return prize;
    }

    public void setPrize(String prize){
        this.prize = prize;
    }

    public boolean matchesID(String id) {
        return this.idNumber.equals(id);
    }

    public boolean matchesEventSeat(String eventid, String seat) {
        return this.eventID.equals(eventid) && this.seatNumber.equals(seat);
    }

    @Override
    public String toString() {
        return name + " " + surname + " (ID: " + idNumber +
               ", Event: " + eventID + ", Seat: " + seatNumber +
               ", Prize: " + (prize == null ? "None" : prize) + ")";
    }
}
