import java.util.Scanner;

public class SnakeTest {
    public static void main(String[] args) {
        SnakeGame game = new SnakeGame();
        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;
        
        while (playAgain) {
            game.initGame();
            while (!game.isGameOver()) {
                game.printGrid();
                System.out.println("Score: " + game.getScore());
                
                System.out.print("Enter direction (Use WASD): ");
                String input = scanner.nextLine().trim();
                if (input.length() > 0) {
                    game.updateDirection(input.charAt(0));
                }
                
                game.moveSnake();
            }

            game.printGrid();
            System.out.println("Game Over. Final Length: " + game.getSnakeLength() + ", Score: " + game.getScore());
            
            System.out.print("Play again? (Y/N): ");
            String choice = scanner.nextLine();
            playAgain = choice.equalsIgnoreCase("Y");
        }
        scanner.close();
    }
}