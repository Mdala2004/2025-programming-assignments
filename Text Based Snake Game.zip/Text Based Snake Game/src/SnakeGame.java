import java.awt.*;
import java.util.Random;

public class SnakeGame {
    private static final int GRID_SIZE = 10;
    private MyArrayListHM<Point> snake;
    private Point food;
    private int score;
    private char direction; // 'W', 'A', 'S', 'D'
    private boolean gameOver;
    private Random random;
    
    public SnakeGame() {
        random = new Random();
    }
    
    public void initGame() {
        snake = new MyArrayListHM<>();
        Point headLocation = new Point(5, 5);
        snake.add(0, headLocation); // Start at center
        generateFood();//generates the food item at its initial location
        score = 0;
        direction = 'D'; // Initial direction: right
        gameOver = false;
    }
    
    private void generateFood() {
        Point newFood;
        do {
            int x = random.nextInt(GRID_SIZE);
            int y = random.nextInt(GRID_SIZE);
            newFood = new Point(x, y);
        } while (containsPoint(snake, newFood));
        food = newFood;
    }
    
    private boolean containsPoint(MyArrayListHM<Point> list, Point p) {//used to check if the snake's body(which does not include the body) doesn't spawn in the same location as foodItem
        for (int i = 0; i < list.getSize(); i++) {
            Point segment = list.get(i);
            if (segment.equals(p)) {
                return true;
            }
        }
        return false;
    }
    
    public void printGrid() {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                Point current = new Point(i, j);//finds the current row and column. Also used to check where a certain item is supposed to be placed
                if (snake.getSize() > 0 && snake.get(snake.getSize() - 1).equals(current)) {
                    System.out.print("H ");
                } else if (food.equals(current)) {
                    System.out.print("* ");
                } else if (containsPoint(snake, current)) {
                    System.out.print("b ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
    }
    
    public void updateDirection(char newDir) {
        if (newDir == 'W' && direction != 'S') 
            direction = 'W';
        else if (newDir == 'A' && direction != 'D') 
            direction = 'A';
        else if (newDir == 'S' && direction != 'W') 
            direction = 'S';
        else if (newDir == 'D' && direction != 'A') 
            direction = 'D';
    }
    
    public void moveSnake() {
        if (snake.getSize() == 0) {
            gameOver = true;
            return;
        }
        
        Point head = snake.get(snake.getSize() - 1);
        int dx = 0, dy = 0;//coordinates of the direction you move the snake in (dx is from left to right, dy is from top to bottom)
        switch (direction) {
            case 'W': 
            dx = -1; 
            break;
            case 'A': 
            dy = -1; 
            break;
            case 'S': 
            dx = 1; 
            break;
            case 'D': 
            dy = 1; 
            break;
        }
        
        int newX = (head.x + dx + GRID_SIZE) % GRID_SIZE;
        int newY = (head.y + dy + GRID_SIZE) % GRID_SIZE;
        Point newHead = new Point(newX, newY);
        
        // Check collision with body (except head)
        for (int i = 0; i < snake.getSize() - 1; i++) {
            if (snake.get(i).equals(newHead)) {
                gameOver = true;
                return;
            }
        }
        
        snake.add(snake.getSize(), newHead);
        
        if (newHead.equals(food)) {
            score++;
            generateFood();
        } else {
            if (snake.getSize() > 1) {
                snake.remove(0);
            }
        }
    }
    
    public boolean isGameOver() {
        return gameOver;
    }
    
    public int getScore() {
        return score;
    }
    
    public int getSnakeLength() {
        return snake.getSize();
    }
}